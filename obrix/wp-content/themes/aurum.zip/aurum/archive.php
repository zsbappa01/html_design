<?php
/**
 *	Aurum WordPress Theme
 *
 *	Laborator.co
 *	www.laborator.co
 */

get_header();

get_template_part('tpls/blog-loop');

get_footer();