## 0.3.0
*(09.10.2016)*
- new fields in frontend submission: reduced, address, zip, public facilities, valuation
- HTML5 validation of required property title field
- user needs to confirm property removal
- rebuilded .pot catalog

## 0.2.1
*(30.06.2016)*
- fixed missing translations
- Colorbox fix for floorplans

## 0.2.0
- option to set Google Browser Key

## 0.1.30
- pay for featured fix
- email in contact info fix
- missing some translations fix
- fix of locations in statistics property views

## 0.1.29
- enquire form fix
- sensor not required warning fix
- missing some translations fix
- .po file replaced by .pot file
- fixed PayPal account payment

## 0.1.28
- fixed prefix of statistics tables
- pagination fix

## 0.1.27
- optimized package system performance
- empty thousand separator fix in price formatting
- empty favorites fix

## 0.1.26
- wire transfer payment gateway

## 0.1.25
- compare fix

## 0.1.23
- jsonrates.com API migrated to currencylayer.com API

## 0.1.16
- fixed property location order
- refactored currencies theme mod
 -- WARNING!: 'realia_pricing_currencies' changed to 'realia_currencies'
 -- WARNING!: 'realia_pricing_currency_jsonrates_api_key' changed to 'realia_currencies_jsonrates_api_key'
 -- WARNING!: 'realia_pricing_currency_other' changed to 'realia_currencies_other'

## 0.1.15
- refactored multiple currency management
- added default enquire email template
- basic support for twenty fifteen
- add_theme_support for currencies, favorites, compare
