# Documentation

## Theme Support Options

| Key                       | Description                            |
|---------------------------|----------------------------------------|
| realia-custom-styles      | Removes custom realia.css styles.      |
| realia-partners           | Enables partners custom post type.     |
| realia-faq                | Enables FAQ custom post type.          |
| realia-pricing            | Enables pricing custom post type.      |
| realia-landlords          | Enables landlors custom post type.     |
| realia-currencies         | Enables multiple currencies support.   |
| realia-import             | Enables import.                        |
| realia-statistics         | Enables statistics.                    |
| realia-favorites          | Enables favorite properties.           |
| realia-compare            | Enables compare properties.            |

## Shortcodes

| Key                             | Description                            |
|---------------------------------|----------------------------------------|
| realia_submission               |                                        |
| realia_submission_list          |                                        |
| realia_submission_remove        |                                        |
| realia_submission_package_info  |                                        |
| realia_submission_payment       |                                        |
| realia_breadcrumb               |                                        |
| realia_currencies               |                                        |
| realia_logout                   |                                        |
| realia_transactions             |                                        |
| realia_compare                  |                                        |
| realia_favorites                |                                        |