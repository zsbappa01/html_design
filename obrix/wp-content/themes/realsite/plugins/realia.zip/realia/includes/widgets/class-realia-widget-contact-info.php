<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Realia_Widget_Contact_Info
 *
 * @class Realia_Widget_Contact_Info
 * @package Realia/Classes/Widgets
 * @author Pragmatic Mates
 */
class Realia_Widget_Contact_Info extends WP_Widget {
    /**
     * Initialize widget
     *
     * @access public
     * @return void
     */
    function Realia_Widget_Contact_Info() {
        parent::__construct(
            'contact_info_widget',
            __( 'Contact Info', 'realia' ),
            array(
                'description' => __( 'Contact info box.', 'realia' ),
            )
        );
    }

    /**
     * Frontend
     *
     * @access public
     * @param array $args
     * @param array $instance
     * @return void
     */
    function widget( $args, $instance ) {
        include Realia_Template_Loader::locate( 'widgets/contact-info' );
    }

    /**
     * Update
     *
     * @access public
     * @param array $new_instance
     * @param array $old_instance
     * @return array
     */
    function update( $new_instance, $old_instance ) {
        return $new_instance;
    }

    /**
     * Backend
     *
     * @access public
     * @param array $instance
     * @return void
     */
    function form( $instance ) {
        include Realia_Template_Loader::locate( 'widgets/contact-info-admin' );
    }
}