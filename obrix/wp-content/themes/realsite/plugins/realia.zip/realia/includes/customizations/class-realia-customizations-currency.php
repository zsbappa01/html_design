<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Realia_Customizations_Currency
 *
 * @class Realia_Customizations_Currency
 * @package Realia/Classes/Customizations
 * @author Pragmatic Mates
 */
class Realia_Customizations_Currency {
    /**
     * Initialize customization type
     *
     * @access public
     * @return void
     */
    public static function init() {
        add_action( 'customize_register', array( __CLASS__, 'customizations' ) );
    }

    /**
     * Customizations
     *
     * @access public
     * @param object $wp_customize
     * @return void
     */
    public static function customizations( $wp_customize ) {
        $wp_customize->add_section( 'realia_currencies[0]', array(
            'title'     => __( 'Realia Currency', 'realia' ),
            'priority'  => 1,
        ) );

        // Currency symbol
        $wp_customize->add_setting( 'realia_currencies[0][symbol]', array(
            // 'default'           => '$',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'sanitize_text_field',
        ) );

        $wp_customize->add_control( 'realia_currencies[0][symbol]', array(
            'label'     => __( 'Currency Symbol', 'realia' ),
            'section'   => 'realia_currencies[0]',
            'settings'  => 'realia_currencies[0][symbol]',
        ) );

        // Currency code
        $wp_customize->add_setting( 'realia_currencies[0][code]', array(
            // 'default'           => 'USD',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'sanitize_text_field',
        ) );

        $wp_customize->add_control( 'realia_currencies[0][code]', array(
            'label'     => __( 'Currency Code', 'realia' ),
            'section'   => 'realia_currencies[0]',
            'settings'  => 'realia_currencies[0][code]',
        ) );

        // Show after
        $wp_customize->add_setting( 'realia_currencies[0][show_after]', array(
            'default'           => false,
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'sanitize_text_field',
        ) );

        $wp_customize->add_control( 'realia_currencies[0][show_after]', array(
            'type'      => 'checkbox',
            'label'     => __( 'Show Symbol After Amount', 'realia' ),
            'section'   => 'realia_currencies[0]',
            'settings'  => 'realia_currencies[0][show_after]',
        ) );

        // Decimal places
        $wp_customize->add_setting( 'realia_currencies[0][money_decimals]', array(
            // 'default'           => '2',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control( 'realia_currencies[0][money_decimals]', array(
            'label'         => __( 'Decimal places', 'realia' ),
            'section'       => 'realia_currencies[0]',
            'settings'      => 'realia_currencies[0][money_decimals]',
        ) );

        // Decimal Separator
        $wp_customize->add_setting( 'realia_currencies[0][money_dec_point]', array(
            // 'default'           => '.',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'sanitize_text_field',
        ) );

        $wp_customize->add_control( 'realia_currencies[0][money_dec_point]', array(
            'label'         => __( 'Decimal Separator', 'realia' ),
            'section'       => 'realia_currencies[0]',
            'settings'      => 'realia_currencies[0][money_dec_point]',
        ) );

        // Thousands Separator
        $wp_customize->add_setting( 'realia_currencies[0][money_thousands_separator]', array(
            // 'default'           => ',',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'sanitize_text_field',
        ) );

        $wp_customize->add_control( 'realia_currencies[0][money_thousands_separator]', array(
            'label'         => __( 'Thousands Separator', 'realia' ),
            'section'       => 'realia_currencies[0]',
            'settings'      => 'realia_currencies[0][money_thousands_separator]',
            'description'   => __( 'If you need space, enter &amp;nbsp;', 'realia' ),
        ) );

	    if ( current_theme_supports( 'realia-currencies' ) ) {
		    // Another currencies
		    $wp_customize->add_setting( 'realia_currencies_other', array(
			    // 'default'           => 0,
			    'capability'        => 'edit_theme_options',
			    'sanitize_callback' => 'sanitize_text_field',
		    ) );

		    $wp_customize->add_control( 'realia_currencies_other', array(
			    'label'       => __( 'Number of additional currencies', 'realia' ),
			    'section'     => 'realia_currencies[0]',
			    'settings'    => 'realia_currencies_other',
			    'description' => __( 'Input positive integer or 0 for no other currencies.', 'realia' ),
		    ) );

		    $other_currencies = get_theme_mod( 'realia_currencies_other', 0 );

		    if ( ! empty( $other_currencies ) && $other_currencies > 0 ) {
			    self::currency_settings( $wp_customize, $other_currencies );
		    }

            // Another currencies
            $wp_customize->add_setting( 'realia_currencies_currencylayer_api_key', array(
                'capability'        => 'edit_theme_options',
                'sanitize_callback' => 'sanitize_text_field',
            ) );

            $wp_customize->add_control( 'realia_currencies_currencylayer_api_key', array(
                'label'         => __( 'currencylayer.com API key', 'realia' ),
                'section'       => 'realia_currencies[0]',
                'settings'      => 'realia_currencies_currencylayer_api_key',
                'description'   => __( 'Enter if you want to automatically update rates of currencies.', 'realia' ),
            ) );
        }
    }

    /**
     * Creates currency options
     *
     * @access public
     * @param object $wp_customize
     * @param int $count
     * @return void
     */
    public static function currency_settings( $wp_customize, $count ) {
        for ( $i = 1; $i <= $count; $i++ ) {
            $wp_customize->add_section( "realia_currencies[$i]", array(
                'title'     => __( 'Realia', 'realia' ) . ' ' . ( $i + 1 ). '. ' . __( 'Currency', 'realia' ),
                'priority'  => 1,
            ) );

            // Currency symbol
            $wp_customize->add_setting( "realia_currencies[$i][symbol]", array(
                'default'           => '',
                'capability'        => 'edit_theme_options',
                'sanitize_callback' => 'sanitize_text_field',
            ) );

            $wp_customize->add_control( "realia_currencies[$i][symbol]", array(
                'label'     => __( 'Currency Symbol', 'realia' ),
                'section'   => "realia_currencies[$i]",
                'settings'  => "realia_currencies[$i][symbol]",
            ) );

            // Currency code
            $wp_customize->add_setting( "realia_currencies[$i][code]", array(
                'default'           => '',
                'capability'        => 'edit_theme_options',
                'sanitize_callback' => 'sanitize_text_field',
            ) );

            $wp_customize->add_control( "realia_currencies[$i][code]", array(
                'label'     => __( 'Currency Code', 'realia' ),
                'section'   => "realia_currencies[$i]",
                'settings'  => "realia_currencies[$i][code]",
            ) );

            // Show after
            $wp_customize->add_setting( "realia_currencies[$i][show_after]", array(
                'default'           => false,
                'capability'        => 'edit_theme_options',
                'sanitize_callback' => 'sanitize_text_field',
            ) );

            $wp_customize->add_control( "realia_currencies[$i][show_after]", array(
                'type'      => 'checkbox',
                'label'     => __( 'Show Symbol After Amount', 'realia' ),
                'section'   => "realia_currencies[$i]",
                'settings'  => "realia_currencies[$i][show_after]",
            ) );

            // Decimal places
            $wp_customize->add_setting( "realia_currencies[$i][money_decimals]", array(
                'default'           => 0,
                'capability'        => 'edit_theme_options',
                'sanitize_callback' => 'sanitize_text_field',
            ) );

            $wp_customize->add_control( "realia_currencies[$i][money_decimals]", array(
                'label'         => __( 'Decimal places', 'realia' ),
                'section'       => "realia_currencies[$i]",
                'settings'      => "realia_currencies[$i][money_decimals]",
            ) );

            // Decimal separator
            $wp_customize->add_setting( "realia_currencies[$i][money_dec_point]", array(
                'default'           => '.',
                'capability'        => 'edit_theme_options',
                'sanitize_callback' => 'sanitize_text_field',
            ) );

            $wp_customize->add_control( "realia_currencies[$i]_money_dec_point", array(
                'label'         => __( 'Decimal Separator', 'realia' ),
                'section'       => "realia_currencies[$i]",
                'settings'      => "realia_currencies[$i][money_dec_point]",
            ) );

            // Thousands Separator
            $wp_customize->add_setting( "realia_currencies[$i][money_thousands_separator]", array(
                'default'           => ',',
                'capability'        => 'edit_theme_options',
                'sanitize_callback' => 'sanitize_text_field',
            ) );

            $wp_customize->add_control( "realia_currencies[$i][money_thousands_separator]", array(
                'label'         => __( 'Thousands Separator', 'realia' ),
                'section'       => "realia_currencies[$i]",
                'settings'      => "realia_currencies[$i][money_thousands_separator]",
                'description'   => __( 'If you need space, enter &amp;nbsp;', 'realia' ),
            ) );

            // Rate
            $wp_customize->add_setting( "realia_currencies[$i][rate]", array(
                'default'           => 1,
                'capability'        => 'edit_theme_options',
                'sanitize_callback' => 'sanitize_text_field',
            ) );

            $wp_customize->add_control( "realia_currencies[$i][rate]", array(
                'label'         => __( 'Rate', 'realia' ),
                'section'       => "realia_currencies[$i]",
                'settings'      => "realia_currencies[$i][rate]",
                'description'   => __( 'Rate from default currency', 'realia' ),
            ) );
        }
    }
}

Realia_Customizations_Currency::init();