<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Realia_Compare
 *
 * @class Realia_Compare
 * @package Realia/Classes
 * @author Pragmatic Mates
 */
class Realia_Compare {
    /**
     * Initialize compare functionality
     *
     * @access public
     * @return void
     */
    public static function init() {
        add_filter( 'query_vars', array( __CLASS__, 'add_query_vars' ) );
        add_action( 'template_redirect', array( __CLASS__, 'remove_catch_template' ), 0 );
        add_action( 'template_redirect', array( __CLASS__, 'add_catch_template' ), 0 );
        add_action( 'template_redirect', array( __CLASS__, 'feed_catch_template' ), 0 );
    }


    /**
     * Adds query vars
     *
     * @access public
     * @param $vars
     * @return array
     */
    public static function add_query_vars( $vars ) {
        $vars[] = 'compare-feed';
        $vars[] = 'compare-add';
        $vars[] = 'compare-remove';

        return $vars;
    }

    /**
     * Removes property from compare
     *
     * @access public
     * @return string
     */
    public static function remove_catch_template() {
        if ( get_query_var( 'compare-remove' ) ) {
            header( 'HTTP/1.0 200 OK' );
            header( 'Content-Type: application/json' );

            $data = array();

            if ( ! empty( $_GET['id'] ) ) {
                if ( ! empty( $_SESSION['compare'] ) && is_array( $_SESSION['compare'] ) ) {
                    foreach( $_SESSION['compare'] as $key => $property_id ) {
                        if ( $property_id == $_GET['id'] ) {
                            unset( $_SESSION['compare'][$key] );
                        }
                    }

                    $data = array(
                        'success' => true,
                    );
                } else {
                    $data = array(
                        'success' => false,
                        'message' => __( 'No properties found in compare list.', 'realia' ),
                    );
                }
            } else {
                $data = array(
                    'success' => false,
                    'message' => __( 'Property ID is missing.', 'realia' ),
                );
            }

            json_encode( $data );
            exit();
        }
    }

    /**
     * Adds property into compare list
     *
     * @access public
     * @return void
     */
    public static function add_catch_template() {
        if ( get_query_var( 'compare-add' ) ) {
            header( 'HTTP/1.0 200 OK' );
            header( 'Content-Type: application/json' );

            if ( ! empty( $_SESSION['compare'] ) && is_array($_SESSION['compare'] ) ) {
                if ( count( $_SESSION['compare'] ) >= REALIA_MAX_COMPARE ) {
                    echo json_encode( array(
                        'success' => false,
                        'message' => sprintf( __( 'You can have max %s properties in list.', 'realia' ), REALIA_MAX_COMPARE ),
                    ) );
                    exit;
                }
            }

            if ( ! empty( $_GET['id'] ) ) {
                if ( empty( $_SESSION['compare'] ) ) {
                    $_SESSION['compare'] = array();
                }

                $post = get_post( $_GET['id'] );
                $post_type = get_post_type( $post->ID );

                if ( $post_type != 'property' ) {
                    $data = array(
                        'success' => false,
                        'message' => __( 'This is not property ID.', 'realia' ),
                    );
                } else {
                    $found = false;

                    foreach ( $_SESSION['compare'] as $property_id ) {
                        if ( $property_id == $_GET['id']) {
                            $found = true;
                            break;
                        }
                    }

                    if ( ! $found ) {
                        $_SESSION['compare'][] = $post->ID;

                        $data = array(
                            'success' => true,
                        );
                    } else {
                        $data = array(
                            'success' => false,
                            'message' => __( 'Property is already in list', 'realia' ),
                        );
                    }
                }
            } else {
                $data = array(
                    'success' => false,
                    'message' => __( 'Property ID is missing.', 'realia' ),
                );
            }

            echo json_encode( $data );
            exit();
        }
    }

    /**
     * Gets list of properties in compare
     *
     * @access public
     * @return void
     */
    public static function feed_catch_template() {
        if ( get_query_var( 'compare-feed' ) ) {
            header( 'HTTP/1.0 200 OK' );
            header( 'Content-Type: application/json' );

            $data = array();
            if ( ! empty( $_SESSION['compare'] ) && is_array( $_SESSION['compare'] ) ) {
                foreach ( $_SESSION['compare'] as $property_id ) {
                    $post = get_post( $property_id );

                    $data[] = array(
                        'id'        => $post->ID,
                        'title'     => get_the_title( $post->ID ),
                        'permalink' => get_permalink( $post->ID ),
                        'src'       => wp_get_attachment_url( get_post_thumbnail_id( $post->ID) ),
                    );
                }
            }

            echo json_encode( $data );
            exit();
        }
    }
}

Realia_Compare::init();