<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Realia_Favorites
 *
 * @class Realia_Favorites
 * @package Realia/Classes
 * @author Pragmatic Mates
 */
class Realia_Favorites {
    /**
     * Initialize favorites functionality
     *
     * @access public
     * @return void
     */
    public static function init() {
        add_filter( 'query_vars', array( __CLASS__, 'add_query_vars' ) );
        add_action( 'template_redirect', array( __CLASS__, 'remove_catch_template' ), 0 );
        add_action( 'template_redirect', array( __CLASS__, 'add_catch_template' ), 0 );
        add_action( 'template_redirect', array( __CLASS__, 'feed_catch_template' ), 0 );
    }

    /**
     * Adds query vars
     *
     * @access public
     * @param $vars
     * @return array
     */
    public static function add_query_vars( $vars ) {
        $vars[] = 'favorites-feed';
        $vars[] = 'favorites-add';
        $vars[] = 'favorites-remove';

        return $vars;
    }

    /**
     * Removes property from list
     *
     * @access public
     * @return string
     */
    public static function remove_catch_template() {
        if ( get_query_var( 'favorites-remove' ) ) {
            header( 'HTTP/1.0 200 OK' );
            header( 'Content-Type: application/json' );

            $data = array();

            if ( ! empty( $_GET['id'] ) ) {
                $favorites = get_user_meta( get_current_user_id(), 'favorites', true );

                if ( ! empty( $favorites ) && is_array( $favorites ) ) {
                    foreach( $favorites as $key => $property_id ) {
                        if ( $property_id == $_GET['id'] ) {
                            unset( $favorites[$key] );
                        }
                    }

                    update_user_meta( get_current_user_id(), 'favorites', $favorites );

                    $data = array(
                        'success' => true,
                    );
                } else {
                    $data = array(
                        'success' => false,
                        'message' => __( 'No properties found in favorites.', 'realia' ),
                    );
                }
            } else {
                $data = array(
                    'success' => false,
                    'message' => __( 'Property ID is missing.', 'realia' ),
                );
            }

            echo json_encode( $data );
            exit();
        }
    }

    /**
     * Adds property into favorites
     *
     * @access public
     * @return void
     */
    public static function add_catch_template() {
        if ( get_query_var( 'favorites-add' ) ) {
            header( 'HTTP/1.0 200 OK' );
            header( 'Content-Type: application/json' );
            $data = array();

            $favorites = get_user_meta( get_current_user_id(), 'favorites', true );
            $favorites = ! is_array( $favorites ) ? array() : $favorites;

            if ( ! empty( $_GET['id'] ) ) {
                if ( empty( $favorites ) ) {
                    $favorites = array();
                }

                $post = get_post( $_GET['id'] );
                $post_type = get_post_type( $post->ID );

                if ( $post_type != 'property' ) {
                    $data = array(
                        'success' => false,
                        'message' => __( 'This is not property ID.', 'realia' ),
                    );
                } else {
                    $found = false;

                    foreach ( $favorites as $property_id ) {
                        if ( $property_id == $_GET['id']) {
                            $found = true;
                            break;
                        }
                    }

                    if ( ! $found ) {
                        $favorites[] = $post->ID;
                        update_user_meta( get_current_user_id(), 'favorites', $favorites );

                        $data = array(
                            'success' => true,
                        );
                    } else {
                        $data = array(
                            'success' => false,
                            'message' => __( 'Property is already in list', 'realia' ),
                        );
                    }
                }
            } else {
                $data = array(
                    'success' => false,
                    'message' => __( 'Property ID is missing.', 'realia' ),
                );
            }

            echo json_encode( $data );
            exit();
        }
    }

    /**
     * Gets list of properties from favorites
     *
     * @access public
     * @return void
     */
    public static function feed_catch_template() {
        if ( get_query_var( 'favorites-feed' ) ) {
            header( 'HTTP/1.0 200 OK' );
            header( 'Content-Type: application/json' );

            $data = array();
            $favorites = get_user_meta( get_current_user_id(), 'favorites', true );

            if ( ! empty( $favorites ) && is_array( $favorites ) ) {
                foreach ( $favorites as $property_id ) {
                    $post = get_post( $property_id );

                    $data[] = array(
                        'id'        => $post->ID,
                        'title'     => get_the_title( $post->ID ),
                        'permalink' => get_permalink( $post->ID ),
                        'src'       => wp_get_attachment_url( get_post_thumbnail_id( $post->ID) ),
                    );
                }
            }

            echo json_encode( $data );
            exit();
        }
    }
}

Realia_Favorites::init();