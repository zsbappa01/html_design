<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Realia_Price
 *
 * @class Realia_Price
 * @package Realia/Classes
 * @author Pragmatic Mates
 */
class Realia_Price {
    /**
     * Gets property price
     *
     * @access public
     * @param null $post_id
     * @return bool|string
     */
    public static function get_property_price( $post_id = null ) {
        if ( $post_id == null ) {
            $post_id = get_the_ID();
        }

        $custom = get_post_meta( $post_id, REALIA_PROPERTY_PREFIX . 'price_custom', true );

        if ( ! empty( $custom ) ) {
            return $custom;
        }

        $price = get_post_meta( $post_id, REALIA_PROPERTY_PREFIX . 'price', true );

        if ( empty( $price ) || ! is_numeric( $price ) ) {
            return false;
        }

        $price = self::format_price( $price );

        $prefix = get_post_meta( $post_id, REALIA_PROPERTY_PREFIX . 'price_prefix', true );
        $suffix = get_post_meta( $post_id, REALIA_PROPERTY_PREFIX . 'price_suffix', true );

        if ( ! empty( $prefix ) ) {
            $price = $prefix . ' ' . $price;
        }

        if ( ! empty( $suffix ) ) {
            $price = $price .  ' ' . $suffix;
        }

        return $price;
    }

    /**
     * Gets price in cents format
     *
     * @access public
     * @param $amount
     * @return int
     */
    public static function get_price_in_cents( $amount ) {
        return intval( $amount * 100 );
    }

    /**
     * Formats price
     *
     * @access public
     * @param $price
     * @param bool $in_default_currency
     * @return bool|string
     */
    public static function format_price( $price, $in_default_currency = false ) {
        if ( empty( $price ) || ! is_numeric( $price ) ) {
            return false;
        }

        $currency_index = $in_default_currency ? 0 : Realia_Currencies::get_current_currency_index();
        $currencies = get_theme_mod( 'realia_currencies' );

        if ( ! $in_default_currency ) {
            $price = $price * Realia_Currencies::get_current_currency_rate();
        }

        $price_parts_dot = explode( '.', $price );
        $price_parts_col = explode( ',', $price );

        if ( count( $price_parts_dot )  > 1 || count( $price_parts_col ) > 1 ) {
            $decimals = ! empty( $currencies[$currency_index]['money_decimals'] ) ? $currencies[$currency_index]['money_decimals'] : '0';
        }  else {
            $decimals = 0;
        }
        $dec_point = ! empty( $currencies[$currency_index]['money_dec_point'] ) ? $currencies[$currency_index]['money_dec_point'] : '.';
        $thousands_separator = ( ! empty( $currencies[$currency_index]['money_thousands_separator'] ) || $currencies[$currency_index]['money_thousands_separator'] == '' ) ? $currencies[$currency_index]['money_thousands_separator'] : ',';

        $price = number_format( $price, $decimals, $dec_point, $thousands_separator );

        $currency_symbol = ! empty( $currencies[$currency_index]['symbol'] ) ? $currencies[$currency_index]['symbol'] : '$';
        $currency_show_symbol_after = ! empty ( $currencies[$currency_index]['show_after'] ) ? true : false;

        if ( ! empty( $currency_symbol ) ) {
            if ( $currency_show_symbol_after ) {
                $price = $price .  ' ' . $currency_symbol;
            } else {
                $price = $currency_symbol . ' ' . $price;
            }
        }

        return $price;
    }

    /**
     * Returns default currency code
     *
     * @access public
     * @return string
     */
    public static function default_currency_code() {
        $currencies = get_theme_mod( 'realia_currencies', array() );

        if ( ! empty( $currencies ) && is_array( $currencies ) ) {
            $currency = array_shift( $currencies );
            $currency_code = $currency['code'];
        } else {
            $currency_code = 'USD';
        }

        return $currency_code;
    }
}