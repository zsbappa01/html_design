<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Realia_Post_Type_Partner
 *
 * @class Realia_Post_Type_Partner
 * @package Realia/Classes/Post_Types
 * @author Pragmatic Mates
 */
class Realia_Post_Type_Partner {
    /**
     * Initialize custom post type
     *
     * @access public
     * @return void
     */
    public static function init() {
        add_action( 'init', array( __CLASS__, 'definition' ) );
        add_filter( 'cmb2_meta_boxes', array( __CLASS__, 'fields' ) );
    }

    /**
     * Custom post type definition
     *
     * @access public
     * @return void
     */
    public static function definition() {
        $labels = array(
            'name'               => __( 'Partners', 'realia' ),
            'singular_name'      => __( 'Partner', 'realia' ),
            'add_new'            => __( 'Add New Partner', 'realia' ),
            'add_new_item'       => __( 'Add New Partner', 'realia' ),
            'edit_item'          => __( 'Edit Partner', 'realia' ),
            'new_item'           => __( 'New Partner', 'realia' ),
            'all_items'          => __( 'All Partners', 'realia' ),
            'view_item'          => __( 'View Partner', 'realia' ),
            'search_items'       => __( 'Search Partner', 'realia' ),
            'not_found'          => __( 'No Partners found', 'realia' ),
            'not_found_in_trash' => __( 'No Partners found in Trash', 'realia' ),
            'parent_item_colon'  => '',
            'menu_name'          => __( 'Partners', 'realia' ),
        );

	    if ( current_theme_supports( 'realia-partners' ) ) {
		    register_post_type( 'partner',
			    array(
				    'labels'              => $labels,
				    'menu_icon'           => 'dashicons-portfolio',
				    'supports'            => array( 'title', 'thumbnail' ),
				    'public'              => true,
				    'exclude_from_search' => true,
				    'publicly_queryable'  => false,
				    'has_archive'         => false,
				    'rewrite'             => false,
				    'menu_position'       => 48,
				    'show_in_nav_menus'   => false,
			    )
		    );
	    }
    }

    /**
     * Defines custom fields
     *
     * @access public
     * @param array $metaboxes
     * @return array
     */
    public static function fields( array $metaboxes ) {
        $metaboxes['url'] = array(
            'id'                    => 'url',
            'title'                 => __( 'URL', 'realia' ),
            'object_types'          => array( 'partner' ),
            'context'               => 'normal',
            'priority'              => 'high',
            'show_names'            => true,
            'fields'                => array(
                array(
                    'name'          => __( 'Partner\'s URL', 'realia' ),
                    'type'          => 'text_url',
                    'id'            => REALIA_PARTNER_PREFIX . 'url',
                ),
            ),
        );

        return $metaboxes;
    }

}

Realia_Post_Type_Partner::init();