<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Realia_Reviews
 *
 * @class Realia_Reviews
 * @package Realia/Classes
 * @property $allowed_post_types
 * @author Pragmatic Mates
 */
class Realia_Reviews {
    /**
     * List of allowed post types for reviews
     *
     * @var array
     */
    public static $allowed_post_types = array( 'property', );

    /**
     * Initialize review system
     *
     * @access public
     * @return void
     */
    public static function init() {
        $enable_reviews = get_theme_mod( 'realia_general_enable_reviews' , false );

        if ( ! empty( $enable_reviews ) ) {
            add_action( 'comments_template', array(__CLASS__, 'get_reviews_template' ) );
            add_action( 'comment_form_default_fields', array(__CLASS__, 'custom_fields' ) );
            add_action( 'comment_post', array(__CLASS__, 'save' ) );
            add_action( 'comment_form_logged_in_after', array(__CLASS__, 'additional_fields' ) );
        }
    }

    /**
     * Get review form and reviews template
     *
     * @access public
     * @param $template
     * @return string
     */
    public static function get_reviews_template( $template ) {
        if ( ! in_array( get_post_type(), Realia_Reviews::$allowed_post_types ) ) {
            return $template;
        }

        return Realia_Template_Loader::locate( 'reviews/review-list' );
    }

    /**
     * Get single review template
     *
     * @access public
     * @param $review
     * @param $args
     * @param $depth
     * @return string
     */
    public static function get_review_template( $review, $args, $depth ) {
        $GLOBALS['comment'] = $review;
        extract( $args, EXTR_SKIP );

        echo Realia_Template_Loader::load( 'reviews/review-single', array(
            'review'    => $review,
            'args'      => $args,
            'depth'     => $depth,
        ) );
    }

    /**
     * Gets post total rating
     *
     * @access public
     * @param int $post_id
     * @return float
     */
    public static function get_post_total_rating( $post_id = null ) {
        global $wpdb;

        if ( empty( $post_id ) ) {
            $post_id = get_the_ID();
        }

        $sql = 'SELECT ROUND(AVG(meta_value), 2) as score FROM ' . $wpdb->prefix . 'comments
	              LEFT JOIN ' . $wpdb->prefix . 'commentmeta ON ' . $wpdb->prefix . 'comments.comment_ID=' . $wpdb->prefix . 'commentmeta.comment_id
                  WHERE comment_post_ID = ' . $post_id .  ' AND
                        meta_key = "rating"
                  GROUP BY comment_post_ID;';

        $results = $wpdb->get_results( $sql );
        if ( ! empty( $results[0] ) ) {
            return $results[0]->score;
        }

        return 0;
    }

    /**
     * Counts reviews for post
     *
     * @access public
     * @param null $post_id
     * @return int
     */
    public static function get_post_reviews_count( $post_id = null ) {
        global $wpdb;

        if ( empty( $post_id ) ) {
            $post_id = get_the_ID();
        }

        $sql = 'SELECT COUNT(comment_post_ID) as count FROM ' . $wpdb->prefix . 'comments
	              LEFT JOIN ' . $wpdb->prefix . 'commentmeta ON ' . $wpdb->prefix . 'comments.comment_ID=' . $wpdb->prefix . 'commentmeta.comment_id
                  WHERE comment_post_ID = ' . $post_id .  ' AND
                        meta_key = "rating"
                  GROUP BY comment_post_ID;';

        $results = $wpdb->get_results( $sql );
        if ( ! empty( $results[0] ) ) {
            return $results[0]->count;
        }

        return 0;
    }

    /**
     * Review's custom fields
     *
     * @access public
     * @param $fields
     * @return mixed
     */
    public static function custom_fields( $fields ) {
        if ( ! in_array( get_post_type(), Realia_Reviews::$allowed_post_types ) ) {
            return $fields;
        }

        $commenter = wp_get_current_commenter();

        if ( empty( $commenter['comment_rating'] ) ) {
            $commenter['comment_rating'] = 0;
        }

        return array(
            'email'             => Realia_Template_Loader::load( 'reviews/review-field-email', array( 'commenter' => $commenter ) ),
            'author'            => Realia_Template_Loader::load( 'reviews/review-field-author', array( 'commenter' => $commenter ) ),
            'rating'            => Realia_Template_Loader::load( 'reviews/review-field-rating', array( 'commenter' => $commenter ) ),
            'url'               => null,
        );
    }

    /**
     * Additional fields for logged in user
     *
     * @access public
     * @return void
     */
    public static function additional_fields() {
        if ( in_array( get_post_type(), Realia_Reviews::$allowed_post_types ) ) {
            $commenter = wp_get_current_commenter();
            echo Realia_Template_Loader::load('reviews/review-field-rating', array('commenter' => $commenter));
        }
    }

    /**
     * Save review
     *
     * @access public
     * @param $comment_id
     * @return void
     */
    public static function save( $comment_id ) {
        if ( ( isset( $_POST['rating'] ) ) && ( $_POST['rating'] != '' ) ) {
            $rating = wp_filter_nohtml_kses( $_POST['rating'] );
            add_comment_meta( $comment_id, 'rating', $rating );
        }
    }
}

Realia_Reviews::init();