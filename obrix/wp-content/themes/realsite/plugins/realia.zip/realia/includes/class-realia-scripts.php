<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Realia_Scripts
 *
 * @class Realia_Scripts
 * @package Realia/Classes
 * @author Pragmatic Mates
 */
class Realia_Scripts {
    /**
     * Initialize scripts
     *
     * @access public
     * @return void
     */
    public static function init() {
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_frontend' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_backend' ) );
        add_action( 'wp_footer', array( __CLASS__, 'enqueue_footer' ) );
    }

    /**
     * Loads frontend files
     *
     * @access public
     * @return void
     */
    public static function enqueue_frontend() {
        $browser_key = get_theme_mod( 'realia_general_google_browser_key' );
        $key = empty( $browser_key ) ? '' : 'key='. $browser_key . '&';

        wp_enqueue_script( 'google-maps', '//maps.googleapis.com/maps/api/js?'. $key .'libraries=weather,geometry,visualization,places,drawing' );

        wp_enqueue_script( 'infobox', plugins_url( '/realia/libraries/jquery-google-map/infobox.js' ), array( 'jquery' ), false, true );
        wp_enqueue_script( 'markerclusterer', plugins_url( '/realia/libraries/jquery-google-map/markerclusterer.js' ), array( 'jquery' ), false, true );
        wp_enqueue_script( 'jquery-google-map', plugins_url( '/realia/libraries/jquery-google-map/jquery-google-map.js' ), array( 'jquery' ), false, true );
        wp_enqueue_script( 'jquery-cookie', plugins_url( '/realia/libraries/jquery.cookie.js' ), array( 'jquery' ), false, true );
        wp_enqueue_script( 'raty', plugins_url( '/realia/libraries/raty/jquery.raty.js' ), array( 'jquery' ), false, true );
        wp_enqueue_script( 'angular', plugins_url( '/realia/libraries/angular.min.js' ), array(), false, true );
        wp_enqueue_script( 'realia-app', plugins_url( '/realia/assets/js/realia-app.js' ), array( 'angular' ), false, true );
        wp_enqueue_script( 'realia', plugins_url( '/realia/assets/js/realia.js' ), array( 'jquery' ), '20161009', true );

        if ( Realia_Recaptcha::is_recaptcha_enabled() ) {
            wp_enqueue_script( 'recaptcha', 'https://www.google.com/recaptcha/api.js?onload=recaptchaCallback&render=explicit', array( 'jquery' ), false, true  );
        }

	    if ( ! current_theme_supports( 'realia-custom-styles') ) {
            wp_enqueue_style( 'realia', plugins_url( '/realia/assets/css/realia.css' ) );
	    }
    }

    /**
     * Loads backend files
     *
     * @access public
     * @return void
     */
    public static function enqueue_backend() {
        wp_register_script( 'd3', plugins_url( '/realia/libraries/d3/d3.v3.js' ), array( 'jquery' ), false, true );
        wp_enqueue_script( 'd3' );

        wp_register_script( 'nvd3', plugins_url( '/realia/libraries/nvd3/nv.d3.min.js' ), array( 'jquery' ), false, true );
        wp_enqueue_script( 'nvd3' );

        wp_register_style( 'nvd3', plugins_url( '/realia/libraries/nvd3/nv.d3.min.css' ) );
        wp_enqueue_style( 'nvd3' );

        wp_register_style( 'nvd3', plugins_url( '/realia/libraries/raty.css' ) );
        wp_enqueue_style( 'nvd3' );

        wp_register_script( 'realia-charts', plugins_url( '/realia/assets/js/realia-charts.js' ), array( 'jquery' ), false, true );
        wp_enqueue_script( 'realia-charts' );

        wp_register_style( 'realia-admin', plugins_url( '/realia/assets/css/realia-admin.css' ) );
        wp_enqueue_style( 'realia-admin' );
    }

    /**
     * Loads javascript into footer
     *
     * @access public
     * @return void
     */
    public static function enqueue_footer() {
        if ( Realia_Recaptcha::is_recaptcha_enabled() && ! is_admin() ) {
            ?>
            <script type="text/javascript">
                var recaptchaCallback = function() {
                    jQuery('.recaptcha').each(function() {

                        var id = jQuery(this).attr('id');
                        var sitekey = jQuery(this).data('sitekey');

                        grecaptcha.render(id, {
                            'sitekey': sitekey
                        });
                    });
                };
            </script>
        <?php
        }
    }
}

Realia_Scripts::init();
