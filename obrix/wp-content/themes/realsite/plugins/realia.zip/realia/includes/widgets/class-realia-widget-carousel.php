<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Realia_Widget_Carousel
 *
 * @class Realia_Widget_Carousel
 * @package Realia/Classes/Widgets
 * @author Pragmatic Mates
 */
class Realia_Widget_Carousel extends WP_Widget {
    /**
     * Initialize widget
     *
     * @access public
     * @return void
     */
    function Realia_Widget_Carousel() {
        parent::__construct(
            'carousel_widget',
            __( 'Property Carousel', 'realia' ),
            array(
                'description' => __( 'Property carousel implementing Bootstrap\'s carousel library.', 'realia' ),
            )
        );
    }

    /**
     * Frontend
     *
     * @access public
     * @param array $args
     * @param array $instance
     * @return void
     */
    function widget( $args, $instance ) {
        $ids = explode( ',', $instance['ids'] );
        include Realia_Template_Loader::locate( 'widgets/carousel' );
    }

    /**
     * Update
     *
     * @access public
     * @param array $new_instance
     * @param array $old_instance
     * @return array
     */
    function update( $new_instance, $old_instance ) {
        return $new_instance;
    }

    /**
     * Backend
     *
     * @access public
     * @param array $instance
     * @return void
     */
    function form( $instance ) {
        include Realia_Template_Loader::locate( 'widgets/carousel-admin' );
    }
}