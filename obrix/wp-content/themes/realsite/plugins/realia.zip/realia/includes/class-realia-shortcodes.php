<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Realia_Shortcodes
 *
 * @class Realia_Shortcodes
 * @package Realia/Classes
 * @author Pragmatic Mates
 */
class Realia_Shortcodes {
    /**
     * Initialize shortcodes
     *
     * @access public
     * @return void
     */
    public static function init() {
        add_shortcode( 'realia_logout', array( __CLASS__, 'logout' ) );
	    add_shortcode( 'realia_currencies', array( __CLASS__, 'currencies' ) );
        add_shortcode( 'realia_breadcrumb', array( __CLASS__, 'breadcrumb' ) );
	    add_shortcode( 'realia_transactions', array( __CLASS__, 'transactions' ) );
	    add_shortcode( 'realia_favorites', array( __CLASS__, 'favorites' ) );
	    add_shortcode( 'realia_compare', array( __CLASS__, 'compare' ) );
        add_shortcode( 'realia_submission', array( __CLASS__, 'submission' ) );
        add_shortcode( 'realia_submission_payment', array( __CLASS__, 'submission_payment' ) );
        add_shortcode( 'realia_submission_remove', array( __CLASS__, 'submission_remove' ) );
        add_shortcode( 'realia_submission_list', array( __CLASS__, 'submission_list' ) );
        add_shortcode( 'realia_submission_package_info', array( __CLASS__, 'submission_package_info' ) );
    }

    /**
     * Logout
     *
     * @access public
     * @return void
     */
    public static function logout( $atts ) {
        $_SESSION['messages'][] = array( 'success', __( 'You have been successfully logged out.', 'realia' ) );
        wp_redirect( html_entity_decode( wp_logout_url( home_url( '/' ) ) ) );
        exit();
    }

    /**
     * Currency switcher
     *
     * @access public
     * @return void|bool|string
     */
    public static function currencies( $atts ) {
        $atts = shortcode_atts( array(), $atts, 'realia_currencies' );

        if ( ! current_theme_supports( 'realia-currencies' ) ) {
            return;
	    }

        $currencies = get_theme_mod( 'realia_currencies' );
        if ( $currencies == false ) {
            $currencies = array(
                array(
                    'symbol'                    => '$',
                    'code'                      => 'USD',
                    'show_after'                => false,
                    'money_decimals'            => 2,
                    'money_dec_point'           => '.',
                    'money_thousands_separator' => ','
                ),
            );
        } elseif ( ! is_array( $currencies ) ) {
            return false;
        }

        array_splice( $currencies, get_theme_mod( 'realia_currencies_other', 0 ) + 1 );
        $result = '';

        if ( ! empty( $currencies ) && is_array( $currencies ) ) {
            ksort($currencies);
            $currency_code = Realia_Currencies::get_current_currency_code();

            $result = '';

            ob_start();
	        include Realia_Template_Loader::locate( 'misc/currencies' );
            $result = ob_get_contents();
            ob_end_clean();
        }

        return $result;
    }

    /**
     * Breadcrumb
     *
     * @access public
     * @return string
     */
    public static function breadcrumb( $atts ) {
        $atts = shortcode_atts( array(), $atts, 'realia_breadcrumb' );
        return Realia_Template_Loader::load( 'misc/breadcrumb' );
    }

    /**
     * Submission index
     *
     * @access public
     * @return string|void
     */
    public static function submission( $atts ) {
	    if ( ! is_user_logged_in() ) {
		    echo Realia_Template_Loader::load( 'misc/not-allowed' );
		    return;
	    }

        $metaboxes = apply_filters( 'cmb2_meta_boxes', array() );

        if ( ! isset( $metaboxes[REALIA_PROPERTY_PREFIX . 'front'] ) ) {
            return __( 'A metabox with the specified \'metabox_id\' doesn\'t exist.', 'realia' );
        }

        // CMB2 is getting fields values from current post what means it will fetch data from submission page
        // We need to remove all data before.
        $post_id = ! empty( $_GET['id'] ) ? $_GET['id'] : false;
        if ( $post_id == false && empty( $_GET['id'] ) ) {
            unset($_POST);

            foreach ( $metaboxes[REALIA_PROPERTY_PREFIX . 'front']['fields'] as $field_name => $field_value ) {
                delete_post_meta( get_the_ID(), $field_value['id'] );
            }
        }

        if ( ! empty( $post_id ) && ! empty( $_POST['object_id'] ) ) {
            $post_id = $_POST['object_id'];
        }

        echo cmb2_get_metabox_form( $metaboxes[REALIA_PROPERTY_PREFIX . 'front'], $post_id, array(
            'form_format' => '<form action="//' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . '" class="cmb-form" method="post" id="%1$s" enctype="multipart/form-data" encoding="multipart/form-data"><input type="hidden" name="object_id" value="%2$s">%3$s<input type="submit" name="submit-cmb" value="%4$s" class="button-primary"></form>',
            'save_button' => __( 'Save property', 'realia' ),
        ) );
    }

    /**
     * Remove submission
     *
     * @access public
     * @return void
     */
    public static function submission_remove( $atts ) {
        $post_id = empty( $_GET['id'] ) ? false : intval( $_GET['id'] );

        if ( ! is_user_logged_in() || ! $post_id ) {
            echo Realia_Template_Loader::load( 'misc/not-allowed' );
            return;
        }

        $is_allowed = Realia_Utilities::is_allowed_to_remove( get_current_user_id(), $post_id );

        if ( ! $is_allowed ) {
            echo Realia_Template_Loader::load( 'misc/not-allowed' );
            return;
        }

        $atts = array(
            'property' => get_post( $post_id )
        );

        echo Realia_Template_Loader::load( 'submission/remove-form', $atts );
    }

	/**
	 * Submission index
	 *
	 * @access public
	 * @param $atts
	 * @return void
	 */
	public static function submission_list( $atts ) {
		if ( ! is_user_logged_in() || ! Realia_Packages::is_allowed_to_add_submission( get_current_user_id() ) ) {
			echo Realia_Template_Loader::load( 'misc/not-allowed' );
			return;
		}

		echo Realia_Template_Loader::load( 'submission/list' );
	}

	/**
	 * Package information
	 *
	 * @access public
	 * @param $atts
	 * @return void
	 */
	public static function submission_package_info( $atts ) {
		if ( ! is_user_logged_in() ) {
			echo Realia_Template_Loader::load( 'misc/not-allowed' );
			return;
		}

		echo Realia_Template_Loader::load( 'submission/package-info' );
	}

	/**
	 * Submission payment
	 *
	 * @access public
	 * @param $atts
	 * @return void
	 */
	public static function submission_payment( $atts ) {
		if ( ! is_user_logged_in() ) {
			echo Realia_Template_Loader::load( 'misc/not-allowed' );
			return;
		}

		echo Realia_Template_Loader::load( 'submission/payment' );
	}

	/**
	 * Transactions
	 *
	 * @access public
	 * @param $atts
	 * @return void
	 */
	public static function transactions( $atts ) {
		if ( ! is_user_logged_in() ) {
			echo Realia_Template_Loader::load( 'misc/not-allowed' );

			return;
		}

		echo Realia_Template_Loader::load( 'misc/transactions' );
	}

	/**
	 * Compare
	 *
	 * @access public
	 * @param $atts
	 * @return void
	 */
	public static function compare( $atts ) {
		echo Realia_Template_Loader::load( 'misc/compare' );
	}

	/**
	 * Favorites
	 *
	 * @access public
	 * @param $atts
	 * @return void
	 */
	public static function favorites( $atts ) {
		if ( ! is_user_logged_in() ) {
			echo Realia_Template_Loader::load( 'misc/not-allowed' );
			return;
		}

		echo Realia_Template_Loader::load( 'misc/favorites' );
	}
}

Realia_Shortcodes::init();