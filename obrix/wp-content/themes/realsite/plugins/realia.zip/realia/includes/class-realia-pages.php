<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Realia_Pages
 *
 * @class Realia_Pages
 * @package Realia/Classes
 * @author Pragmatic Mates
 */
class Realia_Pages {
    /**
     * Initialize specialty pages
     *
     * @access public
     * @return void
     */
    public static function init() {
        add_filter( 'pre_get_posts', array( __CLASS__, 'under_construction' ) );
        add_action( 'wp_footer', array( __CLASS__, 'cookie_policy' ) );
    }

	/**
	 * Gets all pages list
	 *
	 * @access public
	 * @return array
	 */
	public static function get_pages() {
		$pages = array();
		$pages[] =  __( 'Not set', 'realia' );

		foreach ( get_pages() as $page ) {
			$pages[$page->ID] = $page->post_title;
		}

		return $pages;
	}

    /**
     * Under construction page
     *
     * @access public
     * @return void
     */
    public static function under_construction( $query ) {
        $under_construction = get_theme_mod( 'realia_general_under_construction_page', false );

        if ( $under_construction && ! is_user_logged_in() ) {
            $query->set( 'page_id', $under_construction );
        }
    }

    /**
     * Cookie policy page
     *
     * @access public
     * @return void
     */
    public static function cookie_policy() {
        $cookie_policy_page_id = get_theme_mod( 'realia_general_cookie_policy_page', null);
        $under_construction = get_theme_mod( 'realia_general_enable_under_construction', false );

        if ( $under_construction ) {
            return;
        }

        if ( ! empty( $_COOKIE['cookie-policy'] ) && $_COOKIE['cookie-policy'] == true ) {
            return;
        }

        if ( ! empty( $cookie_policy_page_id ) ) {
            include Realia_Template_Loader::locate( 'cookie-policy' );
        }

    }
}

Realia_Pages::init();