<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Realia_Post_Type_Landlord
 *
 * @class Realia_Post_Type_Landlord
 * @package Realia/Classes/Post_Types
 * @author Pragmatic Mates
 */
class Realia_Post_Type_Landlord {
    /**
     * Initialize custom post type
     *
     * @access public
     * @return void
     */
    public static function init() {
	    add_action( 'init', array( __CLASS__, 'definition' ) );
	    add_filter( 'cmb2_meta_boxes', array( __CLASS__, 'fields' ) );
    }

    /**
     * Custom post type definition
     *
     * @access public
     * @return void
     */
    public static function definition() {
        $labels = array(
            'name'                  => __( 'CRM', 'realia' ),
            'singular_name'         => __( 'Landlord', 'realia' ),
            'add_new'               => __( 'Add New', 'realia' ),
            'add_new_item'          => __( 'Add New Landlord', 'realia' ),
            'edit_item'             => __( 'Edit Landlord', 'realia' ),
            'new_item'              => __( 'New Landlord', 'realia' ),
            'all_items'             => __( 'All Landlords', 'realia' ),
            'view_item'             => __( 'View Landlord', 'realia' ),
            'search_items'          => __( 'Search Landlord', 'realia' ),
            'not_found'             => __( 'No landlords found', 'realia' ),
            'not_found_in_trash'    => __( 'No landlords found in Trash', 'realia' ),
            'parent_item_colon'     => '',
            'menu_name'             => __( 'CRM', 'realia' ),
        );

	    if ( current_theme_supports( 'realia-landlords' ) ) {
		    register_post_type( 'landlord', array(
			    'labels'        => $labels,
			    'supports'      => array( 'title', 'editor' ),
			    'public'        => false,
			    'show_ui'       => true,
			    'rewrite'       => false,
			    'menu_position' => 46,
			    'menu_icon'     => 'dashicons-id',
		    ) );
	    }
    }

    /**
     * Defines custom fields
     *
     * @access public
     * @param array $metaboxes
     * @return array
     */
    public static function fields( array $metaboxes ) {
        $metaboxes[REALIA_LANDLORD_PREFIX . 'general'] = array(
            'id'              => REALIA_LANDLORD_PREFIX . 'general',
            'title'           => __( 'General Options', 'realia' ),
            'object_types'    => array( 'landlord' ),
            'context'         => 'normal',
            'priority'        => 'high',
            'show_names'      => true,
            'fields'          => array(
                array(
                    'id'                => REALIA_LANDLORD_PREFIX . 'email',
                    'name'              => __( 'E-mail', 'realia' ),
                    'type'              => 'text',
                ),
                array(
                    'id'                => REALIA_LANDLORD_PREFIX . 'web',
                    'name'              => __( 'Web', 'realia' ),
                    'type'              => 'text',
                ),
                array(
                    'id'                => REALIA_LANDLORD_PREFIX . 'phone',
                    'name'              => __( 'Phone', 'realia' ),
                    'type'              => 'text',
                ),
                array(
                    'id'                => REALIA_LANDLORD_PREFIX . 'address',
                    'name'              => __( 'Address', 'realia' ),
                    'type'              => 'textarea',
                ),
            )
        );

        return $metaboxes;
    }
}

Realia_Post_Type_Landlord::init();