<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Realia_Customizations_General
 *
 * @class Realia_Customizations_General
 * @package Realia/Classes/Customizations
 * @author Pragmatic Mates
 */
class Realia_Customizations_General {
    /**
     * Initialize customization type
     *
     * @access public
     * @return void
     */
    public static function init() {
        add_action( 'customize_register', array( __CLASS__, 'customizations' ) );
    }

    /**
     * Customizations
     *
     * @access public
     * @param object $wp_customize
     * @return void
     */
    public static function customizations( $wp_customize )
    {
        $pages = Realia_Pages::get_pages();

        $wp_customize->add_section('realia_general', array(
            'title' => __('Realia General', 'realia'),
            'priority' => 1,
        ));

        // Under construction
        $wp_customize->add_setting('realia_general_under_construction_page', array(
            'default' => false,
            'capability' => 'edit_theme_options',
            'sanitize_callback' => 'sanitize_text_field',
        ));

        $wp_customize->add_control('realia_general_under_construction_page', array(
            'type' => 'select',
            'label' => __('Under Construction Page', 'realia'),
            'section' => 'realia_general',
            'settings' => 'realia_general_under_construction_page',
            'choices' => $pages,
        ));

        // Cookie policy
        $wp_customize->add_setting('realia_general_cookie_policy_page', array(
            'default' => null,
            'capability' => 'edit_theme_options',
            'sanitize_callback' => 'sanitize_text_field',
        ));

        $wp_customize->add_control('realia_general_cookie_policy_page', array(
            'type' => 'select',
            'label' => __('Cookie Policy Page', 'realia'),
            'section' => 'realia_general',
            'settings' => 'realia_general_cookie_policy_page',
            'choices' => $pages,
        ));

        if ( current_theme_supports( 'realia-compare' ) ) {
            // Compare page
            $wp_customize->add_setting('realia_general_compare_page', array(
                'default' => null,
                'capability' => 'edit_theme_options',
                'sanitize_callback' => 'sanitize_text_field',
            ));

            $wp_customize->add_control('realia_general_compare_page', array(
                'type' => 'select',
                'label' => __('Compare Page', 'realia'),
                'section' => 'realia_general',
                'settings' => 'realia_general_compare_page',
                'choices' => $pages,
            ));
        }

        if ( current_theme_supports( 'realia-favorite' ) ) {
            // Favorites page
            $wp_customize->add_setting('realia_general_favorites_page', array(
                'default' => null,
                'capability' => 'edit_theme_options',
                'sanitize_callback' => 'sanitize_text_field',
            ));

            $wp_customize->add_control('realia_general_favorites_page', array(
                'type' => 'select',
                'label' => __('Favorites Page', 'realia'),
                'section' => 'realia_general',
                'settings' => 'realia_general_favorites_page',
                'choices' => $pages,
            ));
        }

        // Login required
        $wp_customize->add_setting( 'realia_general_login_required_page', array(
            'default'           => null,
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'sanitize_text_field',
        ) );

        $wp_customize->add_control( 'realia_general_login_required_page', array(
            'type'          => 'select',
            'label'         => __( 'Login Required Page', 'realia' ),
            'section'       => 'realia_general',
            'settings'      => 'realia_general_login_required_page',
            'choices'       => $pages,
        ) );

        // After login page
        $wp_customize->add_setting( 'realia_general_after_login_page', array(
            'default'           => null,
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'sanitize_text_field',
        ) );

        $wp_customize->add_control( 'realia_general_after_login_page', array(
            'type'          => 'select',
            'label'         => __( 'After Login Page', 'realia' ),
            'section'       => 'realia_general',
            'settings'      => 'realia_general_after_login_page',
            'choices'       => $pages,
        ) );

        // Profile page
        $wp_customize->add_setting( 'realia_general_profile_page', array(
            'default'           => null,
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'sanitize_text_field',
        ) );

        $wp_customize->add_control( 'realia_general_profile_page', array(
            'type'          => 'select',
            'label'         => __( 'Profile Page', 'realia' ),
            'section'       => 'realia_general',
            'settings'      => 'realia_general_profile_page',
            'choices'       => $pages,
        ) );

        // Change password page
        $wp_customize->add_setting( 'realia_general_password_page', array(
            'default'           => null,
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'sanitize_text_field',
        ) );

        $wp_customize->add_control( 'realia_general_password_page', array(
            'type'          => 'select',
            'label'         => __( 'Password Page', 'realia' ),
            'section'       => 'realia_general',
            'settings'      => 'realia_general_password_page',
            'choices'       => $pages,
        ) );

	    if ( current_theme_supports( 'realia-statistics' ) ) {
		    // Query logging
		    $wp_customize->add_setting( 'realia_general_enable_query_logging', array(
			    'default'           => false,
			    'capability'        => 'edit_theme_options',
			    'sanitize_callback' => 'sanitize_text_field',
		    ) );

		    $wp_customize->add_control( 'realia_general_enable_query_logging', array(
			    'type'     => 'checkbox',
			    'label'    => __( 'Enable Search Query Logging', 'realia' ),
			    'section'  => 'realia_general',
			    'settings' => 'realia_general_enable_query_logging',
		    ) );

		    // Property logging
		    $wp_customize->add_setting( 'realia_general_enable_property_logging', array(
			    'default'           => false,
			    'capability'        => 'edit_theme_options',
			    'sanitize_callback' => 'sanitize_text_field',
		    ) );

		    $wp_customize->add_control( 'realia_general_enable_property_logging', array(
			    'type'     => 'checkbox',
			    'label'    => __( 'Enable Property Views Logging', 'realia' ),
			    'section'  => 'realia_general',
			    'settings' => 'realia_general_enable_property_logging',
		    ) );
	    }

        // Enable reviews
        $wp_customize->add_setting( 'realia_general_enable_reviews', array(
            'default'           => false,
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'sanitize_text_field',
        ) );

        $wp_customize->add_control( 'realia_general_enable_reviews', array(
            'type'      => 'checkbox',
            'label'     => __( 'Enable Reviews', 'realia' ),
            'section'   => 'realia_general',
            'settings'  => 'realia_general_enable_reviews',
        ) );

        if ( current_theme_supports( 'realia-compare' ) ) {
            // Enable compare
            $wp_customize->add_setting( 'realia_general_enable_compare', array(
                'default'           => false,
                'capability'        => 'edit_theme_options',
                'sanitize_callback' => 'sanitize_text_field',
            ));

            $wp_customize->add_control( 'realia_general_enable_compare', array(
                'type'      => 'checkbox',
                'label'     => __('Enable Compare', 'realia'),
                'section'   => 'realia_general',
                'settings'  => 'realia_general_enable_compare',
            ) );
        }

        if ( current_theme_supports( 'realia-favorites' ) ) {
            // Enable favorites
            $wp_customize->add_setting( 'realia_general_enable_favorites', array(
                'default'           => false,
                'capability'        => 'edit_theme_options',
                'sanitize_callback' => 'sanitize_text_field',
            ) );

            $wp_customize->add_control('realia_general_enable_favorites', array(
                'type'          => 'checkbox',
                'label'         => __('Enable Favorites', 'realia'),
                'section'       => 'realia_general',
                'settings'      => 'realia_general_enable_favorites',
            ) );
        }

        // Hide unassigned amenities
        $wp_customize->add_setting( 'realia_general_hide_unassigned_amenities', array(
            'default'           => false,
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'sanitize_text_field',
        ) );

        $wp_customize->add_control( 'realia_general_hide_unassigned_amenities', array(
            'type'      => 'checkbox',
            'label'     => __( 'Hide Unassigned Amenities', 'realia' ),
            'section'   => 'realia_general',
            'settings'  => 'realia_general_hide_unassigned_amenities',
        ) );

        // Show property archive as grid
        $wp_customize->add_setting( 'realia_general_show_property_archive_as_grid', array(
            'default'           => false,
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'sanitize_text_field',
        ) );

        $wp_customize->add_control( 'realia_general_show_property_archive_as_grid', array(
            'type'      => 'checkbox',
            'label'     => __( 'Show property archive as grid', 'realia' ),
            'section'   => 'realia_general',
            'settings'  => 'realia_general_show_property_archive_as_grid',
        ) );

        // Google browser API key
        $wp_customize->add_setting( 'realia_general_google_browser_key', array(
            'default'           => null,
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'sanitize_text_field',
        ) );

        $wp_customize->add_control( 'realia_general_google_browser_key', array(
            'type'          => 'text',
            'label'         => __( 'Google Browser Key', 'realia' ),
            'description'   => __( 'Browser API key. Read more <a href="https://developers.google.com/maps/documentation/javascript/get-api-key" target="_blank">here</a>.', 'realia' ),
            'section'       => 'realia_general',
            'settings'      => 'realia_general_google_browser_key',
        ) );
    }
}

Realia_customizations_General::init();
