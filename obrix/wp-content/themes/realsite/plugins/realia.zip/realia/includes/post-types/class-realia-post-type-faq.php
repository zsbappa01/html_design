<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Realia_Post_Type_Faq
 *
 * @class Realia_Post_Type_Faq
 * @package Realia/Classes/Post_Types
 * @author Pragmatic Mates
 */
class Realia_Post_Type_Faq {
    /**
     * Initialize custom post type
     *
     * @access public
     * @return void
     */
    public static function init() {
	    add_action( 'init', array( __CLASS__, 'definition' ) );
    }

    /**
     * Custom post type definition
     *
     * @access public
     * @return void
     */
    public static function definition() {
        $labels = array(
            'name'               => __( 'FAQ', 'realia' ),
            'singular_name'      => __( 'FAQ', 'realia' ),
            'add_new'            => __( 'Add New FAQ', 'realia' ),
            'add_new_item'       => __( 'Add New FAQ', 'realia' ),
            'edit_item'          => __( 'Edit FAQ', 'realia' ),
            'new_item'           => __( 'New FAQ', 'realia' ),
            'all_items'          => __( 'All FAQ', 'realia' ),
            'view_item'          => __( 'View FAQ', 'realia' ),
            'search_items'       => __( 'Search FAQ', 'realia' ),
            'not_found'          => __( 'No FAQ found', 'realia' ),
            'not_found_in_trash' => __( 'No FAQ found in Trash', 'realia' ),
            'parent_item_colon'  => '',
            'menu_name'          => __( 'FAQ', 'realia' ),
        );

	    if ( current_theme_supports( 'realia-faq' ) ) {
		    register_post_type( 'faq', array(
			    'labels'        => $labels,
			    'supports'      => array( 'title', 'editor' ),
			    'public'        => true,
			    'show_ui'       => true,
			    'has_archive'   => true,
			    'rewrite'       => array( 'slug' => __( 'faq', 'realia' ) ),
			    'menu_position' => 49,
			    'categories'    => array(),
			    'menu_icon'     => 'dashicons-editor-help'
		    ) );
	    }
    }
}

Realia_Post_Type_Faq::init();