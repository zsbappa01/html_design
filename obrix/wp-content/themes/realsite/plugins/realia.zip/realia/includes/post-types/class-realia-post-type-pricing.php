<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Realia_Post_Type_Pricing
 *
 * @class Realia_Post_Type_Pricing
 * @package Realia/Classes/Post_Types
 * @author Pragmatic Mates
 */
class Realia_Post_Type_Pricing {
	/**
	 * Initialize pricing custom post type
	 *
	 * @access public
	 * @return void
	 */
    public static function init() {
	    add_action( 'init', array( __CLASS__, 'definition' ) );
	    add_filter( 'cmb2_meta_boxes', array( __CLASS__, 'fields' ) );
    }

    /**
     * Custom post type definition
     *
     * @access public
     * @return void
     */
    public static function definition() {
        $labels = array(
            'name'               => __( 'Pricing', 'realia' ),
            'singular_name'      => __( 'Pricing', 'realia' ),
            'add_new'            => __( 'Add New Pricing', 'realia' ),
            'add_new_item'       => __( 'Add New Pricing', 'realia' ),
            'edit_item'          => __( 'Edit Pricing', 'realia' ),
            'new_item'           => __( 'New Pricing', 'realia' ),
            'all_items'          => __( 'All Pricing', 'realia' ),
            'view_item'          => __( 'View Pricing', 'realia' ),
            'search_items'       => __( 'Search Pricing', 'realia' ),
            'not_found'          => __( 'No pricing found', 'realia' ),
            'not_found_in_trash' => __( 'No pricing found in Trash', 'realia' ),
            'parent_item_colon'  => '',
            'menu_name'          => __( 'Pricing', 'realia' ),
        );

	    if ( current_theme_supports( 'realia-pricing' ) ) {
		    register_post_type( 'pricing',
			    array(
				    'labels'        => $labels,
				    'menu_icon'     => 'dashicons-list-view',
				    'supports'      => array( 'title' ),
				    'public'        => true,
				    'has_archive'   => true,
				    'rewrite'       => array( 'slug' => __( 'pricing', 'realia' ) ),
				    'menu_position' => 50,
			    )
		    );
	    }
    }

    /**
     * Defines custom fields
     *
     * @access public
     * @param array $metaboxes
     * @return array
     */
    public static function fields( array $metaboxes ) {
        $metaboxes['basic'] = array(
            'id'                    => 'basic',
            'title'                 => __( 'Basic Settings', 'realia' ),
            'object_types'          => array( 'pricing' ),
            'context'               => 'normal',
            'priority'              => 'high',
            'show_names'            => true,
            'fields'                => array(
                array(
                    'name' => __( 'Price', 'realia' ),
                    'id'   => REALIA_PRICING_PREFIX . 'price',
                    'type' => 'text_medium',
                ),
                array(
                    'name' => __( 'Button Text', 'realia' ),
                    'id'   => REALIA_PRICING_PREFIX . 'button_text',
                    'type' => 'text_medium',
                ),
                array(
                    'name' => __( 'Button Link', 'realia' ),
                    'id'   => REALIA_PRICING_PREFIX . 'button_url',
                    'type' => 'text_url',
                ),
                array(
                    'name' => __( 'Label Text', 'realia' ),
                    'id'   => REALIA_PRICING_PREFIX . 'label_text',
                    'type' => 'text_medium',
                ),
                array(
                    'name' => __( 'Highlight Table?', 'realia' ),
                    'id'   => REALIA_PRICING_PREFIX . 'highlighted',
                    'type' => 'checkbox',
                ),
            ),
        );

        $metaboxes['pricing_items'] = array(
            'id'                    => 'pricing_items',
            'title'                 => __( 'Pricing Table Items', 'realia' ),
            'object_types'          => array( 'pricing' ),
            'context'               => 'normal',
            'priority'              => 'high',
            'show_names'            => true,
            'fields'                => array(
                array(
                    'name'          => __( 'Item (row)', 'realia' ),
                    'id'            => REALIA_PRICING_PREFIX . 'items',
                    'type'          => 'text',
                    'repeatable'    => true,
                )
            ),
        );

        return $metaboxes;
    }
}

Realia_Post_Type_Pricing::init();