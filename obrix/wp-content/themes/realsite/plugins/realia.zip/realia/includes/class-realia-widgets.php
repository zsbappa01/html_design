<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Realia_Widgets
 *
 * @class Realia_Widgets
 * @package Realia/Classes/Widgets
 * @author Pragmatic Mates
 */
class Realia_Widgets {
    /**
     * Initialize widgets
     *
     * @access public
     * @return void
     */
    public static function init() {
        self::includes();
        add_action( 'widgets_init', array( __CLASS__, 'register' ) );

    }

    /**
     * Include widget classes
     *
     * @access public
     * @return void
     */
    public static function includes() {
        require_once REALIA_DIR . 'includes/widgets/class-realia-widget-agents.php';
        require_once REALIA_DIR . 'includes/widgets/class-realia-widget-agent-assigned.php';
        require_once REALIA_DIR . 'includes/widgets/class-realia-widget-carousel.php';
        require_once REALIA_DIR . 'includes/widgets/class-realia-widget-carousel-small.php';
        require_once REALIA_DIR . 'includes/widgets/class-realia-widget-compare.php';
        require_once REALIA_DIR . 'includes/widgets/class-realia-widget-contact-info.php';
        require_once REALIA_DIR . 'includes/widgets/class-realia-widget-cover.php';
        require_once REALIA_DIR . 'includes/widgets/class-realia-widget-enquire.php';
        require_once REALIA_DIR . 'includes/widgets/class-realia-widget-favorites.php';
        require_once REALIA_DIR . 'includes/widgets/class-realia-widget-horizontal-filter.php';
        require_once REALIA_DIR . 'includes/widgets/class-realia-widget-partners.php';
        require_once REALIA_DIR . 'includes/widgets/class-realia-widget-properties.php';
        require_once REALIA_DIR . 'includes/widgets/class-realia-widget-properties-map.php';
        require_once REALIA_DIR . 'includes/widgets/class-realia-widget-rating.php';
        require_once REALIA_DIR . 'includes/widgets/class-realia-widget-simple-map.php';
        require_once REALIA_DIR . 'includes/widgets/class-realia-widget-vertical-filter.php';
    }

    /**
     * Register widgets
     *
     * @access public
     * @return void
     */
    public static function register() {
        register_widget( 'Realia_Widget_Agents' );
        register_widget( 'Realia_Widget_Agent_Assigned' );
        register_widget( 'Realia_Widget_Vertical_Filter' );
        register_widget( 'Realia_Widget_Horizontal_Filter' );
        register_widget( 'Realia_Widget_Enquire' );
        register_widget( 'Realia_Widget_Carousel' );
        register_widget( 'Realia_Widget_Properties' );
        register_widget( 'Realia_Widget_Properties_Map' );

	    if ( current_theme_supports( 'realia-partners' ) ) {
		    register_widget( 'Realia_Widget_Partners' );
	    }

        register_widget( 'Realia_Widget_Carousel_Small' );
        register_widget( 'Realia_Widget_Cover' );

	    if ( current_theme_supports( 'realia-compare' ) ) {
	        register_widget( 'Realia_Widget_Compare' );
        }

	    if ( current_theme_supports( 'realia-favorites' ) ) {
		    register_widget( 'Realia_Widget_Favorites' );
	    }

        register_widget( 'Realia_Widget_Rating' );
        register_widget( 'Realia_Widget_Simple_Map' );
        register_widget( 'Realia_Widget_Contact_Info' );
    }
}

Realia_Widgets::init();