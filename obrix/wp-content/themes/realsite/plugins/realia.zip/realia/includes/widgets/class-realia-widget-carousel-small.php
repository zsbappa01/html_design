<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Realia_Widget_Carousel_Small
 *
 * @class Realia_Widget_Carousel_Small
 * @package Realia/Classes/Widgets
 * @author Pragmatic Mates
 */
class Realia_Widget_Carousel_Small extends WP_Widget {
    /**
     * Initialize widget
     *
     * @access public
     * @return void
     */
    function Realia_Widget_Carousel_Small() {
        parent::__construct(
            'carousel_small_widget',
            __( 'Property Small Carousel', 'realia' ),
            array(
                'description' => __( 'Small property carousel implementing OwlCarousel.', 'realia' ),
            )
        );
    }

    /**
     * Frontend
     *
     * @access public
     * @param array $args
     * @param array $instance
     * @return void
     */
    function widget( $args, $instance ) {
        $query = array(
            'post_type'         => 'property',
            'posts_per_page'    => ! empty( $instance['count'] ) ? $instance['count'] : 10,
        );

        if ( ! empty( $instance['attribute'] ) ) {
            if ( $instance['attribute'] == 'featured' ) {
                $query['meta_query'][] = array(
                    'key'       => REALIA_PROPERTY_PREFIX . 'featured',
                    'value'     => 'on',
                    'compare'   => '==',
                );
            } elseif ( $instance['attribute'] == 'reduced' ) {
                $query['meta_query'][] = array(
                    'key'       => REALIA_PROPERTY_PREFIX . 'reduced',
                    'value'     => 'on',
                    'compare'   => '==',
                );
            }
        }

        query_posts( $query );
        include Realia_Template_Loader::locate( 'widgets/carousel-small' );

        wp_reset_query();
    }

    /**
     * Update
     *
     * @access public
     * @param array $new_instance
     * @param array $old_instance
     * @return array
     */
    function update( $new_instance, $old_instance ) {
        return $new_instance;
    }

    /**
     * Backend
     *
     * @access public
     * @param array $instance
     * @return void
     */
    function form( $instance ) {
        include Realia_Template_Loader::locate( 'widgets/carousel-small-admin' );
    }
}