var app = angular.module('realia', []);

app.controller('CompareController', function($scope, $http) {
	$scope.properties = [];

	$http.get('?compare-feed=true').success(function(data) {
		$scope.properties = data;
	});


	$scope.update = function() {
		$http.get('?compare-feed=true').success(function(data) {
			$scope.properties = data;
		});				
	};

	$scope.remove = function(id) {		
		$http.get('?compare-remove=true&id=' + id).success(function(data) {
			angular.forEach($scope.properties, function(value, key) {
				if (id == value.id) {					
					$scope.properties.splice(key, 1);
				}
			});			
		});		
	};

	$scope.get_ids = function() {
		var result = '';
		var index = 1;

		angular.forEach($scope.properties, function(value, key) {
			result += value.id;			
			
			if (index != $scope.properties.length) {
				result += ',';
			}

			index++;
		});

		return result;
	};
});

app.controller('CompareAddController', function($scope, $http) {
	$scope.add = function(id) {
		$http.get('?compare-add=true&id=' + id).success(function(data) {
			if (data.success == false) {
				alert(data.message);
			}

			var widget_scope = angular.element(document.getElementById("compare-controller")).scope();		    
		    widget_scope.update();
		});
	};
});

app.service( 'FavoritesService', ['$http', function($http) {	
	return {
		getProperties: function() {
			return $http.get('?favorites-feed=true').then(function(result) {				
				return result.data;
			});
		}
	}
}]);

app.controller('FavoritesController', function($scope, $http, FavoritesService) {
	$scope.properties = [];

	FavoritesService.getProperties().then(function(data) {
		$scope.properties = data;
	});

	$scope.remove = function(id) {
		$http.get('?favorites-remove=true&id=' + id).success(function(data) {
			if (data.success == false) {
				alert(data.message);
			}

			angular.forEach($scope.properties, function(value, key) {
				if (value.id == id) {
					$scope.properties.splice(key, 1);
				}
			});
		});
	};

	$scope.update = function() {
		$http.get('?favorites-feed=true').success(function(data) {
			$scope.properties = data;
		});			
	}
});

app.controller('FavoritesAddController', function($scope, $http, FavoritesService) {	
	$scope.properties = [];

	FavoritesService.getProperties().then(function(data) {
		$scope.properties = data;		
	});
	
	$scope.is_included = function(id) {					
		var found = false;

		angular.forEach($scope.properties, function(value, key) {			
			if (id == value.id) {				
				found = id;
			}
		});		

		if (!found) {
			return false;
		}

		return true;
	};

	$scope.remove = function(id) {
		$http.get('?favorites-remove=true&id=' + id).success(function(data) {
			if (data.success == false) {
				alert(data.message);
			}

			angular.forEach($scope.properties, function(value, key) {
				if (value.id == id) {
					$scope.properties.splice(key, 1);
				}
			});

			var widget_scope = angular.element(document.getElementById("favorites-controller")).scope();		    
		    widget_scope.update();			
		});
	}

	$scope.add = function(id) {
		$http.get('?favorites-add=true&id=' + id).success(function(data) {
			if (data.success == false) {
				alert(data.message);
			}

			$scope.properties = FavoritesService.getProperties().then(function(data) {
				$scope.properties = data;
			});

			var widget_scope = angular.element(document.getElementById("favorites-controller")).scope();		    
		    widget_scope.update();						
		});
	}
});
